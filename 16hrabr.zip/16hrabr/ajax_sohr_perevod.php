<?php
include "db.php";
$lang = $_POST[lang]; if($lang=='ch')$lang='';
$text = $_POST[text]; $text = str_replace("'", "\'", $text ); $text = str_replace("\\'", "\'", $text ); $text = str_replace("\\\'", "\'", $text );
$text = str_replace('<font style="vertical-align: inherit;">', '', $text );$text = str_replace('</font>', '', $text );

if($lang=='ru'){
  $date_Y_m = date("Y-m"); $date_day = date("d");
  $article = str_replace("/", "-", $_POST[article]);
  file_put_contents( 'articles/'.$date_Y_m.'/'.$date_day.'/'.$article.'.html', $text ); // Сохраняем статью в файл
}
else{
  $filename = $_POST[article];
  $skybase_id = mysqli_query($db, "SELECT id FROM skyblog_blog$lang WHERE pic='$filename'");
  if (!$skybase_id)
  { echo "<p>База данных не доступна<br> <strong>Ошибка: </strong></p>";
    exit(mysqli_error($db)); }
  if (mysqli_num_rows($skybase_id) == 0)// если статьи нет в базе данных
  {

    $pos = strpos($text,'</span>'); $title = substr( $text, 21, $pos - 21 );
    $pos1 = strpos($text,'</span>',$pos+7); $avtor = substr( $text, $pos + 32, $pos1 - $pos - 32 );//27
    $text = ' '.substr( $text, $pos1 + 7 ); // Ставим впереди пробел, иначе функция replace_font_to_span не будет работать

    //replace_font_to_span();

    $catid = 1;  $title = strip_tags($title);
    $title = str_replace("'", "\'", $title );  $title = str_replace("\\'", "\'", $title ); $title = str_replace("\\\'", "\'", $title );
    $kslova = str_replace(" ", ",", $title); $descript = $title;
    $cortext = strip_tags($text); $cortext = substr($cortext, 0, 800); //
    $data = date('Y-m-d');

    $skybaseaddblog = mysqli_query ($db, "INSERT INTO skyblog_blog$lang (cat,title,kslova,descript,cortext,text,avtor,data,pic) VALUES ('$catid','$title','$kslova','$descript','$cortext','$text','$avtor','$data','$filename')");
     // в базу данных
    if (!$skybaseaddblog)
							{
							//echo "<br><div class=alert>Статья не добавлена.<br> <strong>Ошибка: </strong></div>";
							exit(mysqli_error($db).$cortext);
							}
  }
}


function replace_font_to_span(){
  global $text;
  $text = str_replace('</font></font>', '</span>', $text ); $text = str_replace('</font>', '</span>', $text );
  $pos_pred = 1; $id = 0;
  while( $pos_pred ){//echo $pos_pred;
    $pos = strpos( $text, '<font style="vertical-align: inherit;">', $pos_pred );
    if( $pos ){
      $pos2 = strpos( $text, '<font style="vertical-align: inherit;">', $pos + 1 );
      $text_with_spans = $text_with_spans.substr( $text, $pos_pred, $pos - $pos_pred ).'<span id="s'.$id.'" onclick="f();">';
      $id++;
      if( $pos2 == $pos + 39 ){ $pos_pred = $pos + 78;       } // если двойной font
      else{ $pos_pred = $pos + 39;         } // если одинарный font
    }
    else{ $text_with_spans = $text_with_spans.substr( $text, $pos_pred, strlen( $text ) ); $pos_pred = false; }
  }
  $text = $text_with_spans;
}
?>
