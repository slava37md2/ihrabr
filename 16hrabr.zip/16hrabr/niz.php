<!--
#	....................... ..........................................................
#
#		Автор:	Sky (http://skystudio.ru http://skyscript.ru)
#
#	.................................................................................
-->
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" background="pic/skyscript_fon_niz.png">
  <tr>
    <td align="center"><table width="950" height="68" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="33"></td>
        <td width="210" align="left"><div class="sm2">Бесплатные PHP-скрипты<br />
          <a href="http://www.skyscript.ru">2009&mdash;2010 SkyScript.ru</a></div></td>
        <td width="33">&nbsp;</td>
        <td align="left"><div class="sm2">Блоги  <span class="kr">SkyBlog</span> версия 1.0<br />
          Работает на PHP + MySQL </div></td>
        <td width="33">&nbsp;</td>
        <td align="right"><!--Rating@Mail.ru counter-->
          <script language="JavaScript" type="text/javascript"><!--
d=document;var a='';a+=';r='+escape(d.referrer);js=10;//--></script>
          <script language="JavaScript1.1" type="text/javascript"><!--
a+=';j='+navigator.javaEnabled();js=11;//--></script>
          <script language="JavaScript1.2" type="text/javascript"><!--
s=screen;a+=';s='+s.width+'*'+s.height;
a+=';d='+(s.colorDepth?s.colorDepth:s.pixelDepth);js=12;//--></script>
          <script language="JavaScript1.3" type="text/javascript"><!--
js=13;//--></script>
          <script language="JavaScript" type="text/javascript"><!--
d.write('<a href="http://top.mail.ru/jump?from=1671954" target="_top">'+
'<img src="http://d3.c8.b9.a1.top.mail.ru/counter?id=1671954;t=84;js='+js+
a+';rand='+Math.random()+'" alt="Рейтинг@Mail.ru" border="0" '+
'height="18" width="88"><\/a>');if(11<js)d.write('<'+'!-- ');//--></script>
          <noscript>
            <a target="_top" href="http://top.mail.ru/jump?from=1671954"> <img src="http://d3.c8.b9.a1.top.mail.ru/counter?js=na;id=1671954;t=84" 
height="18" width="88" border="0" alt="Рейтинг@Mail.ru" /></a>
            </noscript>
          <script language="JavaScript" type="text/javascript"><!--
if(11<js)d.write('--'+'>');//--></script>
          <!--// Rating@Mail.ru counter--></td>
        <td width="33" align="right"></td>
      </tr>
    </table></td>
  </tr>
</table>