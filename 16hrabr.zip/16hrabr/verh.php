<!--
#	....................... ..........................................................
#
#		Автор:	Sky (http://skystudio.ru http://skyscript.ru)
#
#	.................................................................................
-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF8" />
<link href="st.css" rel="stylesheet" type="text/css">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" background="pic/skyscript_fon_verh.png">
  <tr>
    <td align="center">



<table width="950" border="0" align="center" cellpadding="0" cellspacing="0" background="pic/skyscript_fon_verh.png">
  <tr>
    <td width="275"><a href="http://www.skyscript.ru"><img title="Бесплатные скрипты — SkyScript" src="pic/skyscript_logo.png" width="275" height="100" border="0"></a></td>
    <td>&nbsp;</td>
    <td><span class="name">Бесплатный Скрипт</span> блога Sky<span class="name">Blog</span> ver 1.0</td>
  </tr>
</table>


</td>
  </tr>
</table>
