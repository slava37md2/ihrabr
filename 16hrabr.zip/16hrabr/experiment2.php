<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>experiment</title>
</head>
<body>
<div id="bodyofthedocument"><span class="title1">Возможности Heap Table в PostgreSQL</span>.<span class="avtor">
      azatyakupov
    </span>Эта статья переведена с русского языка. Источник с комментариями здесь: <a href="https://habr.com/ru/company/quadcode/blog/671254/">https://habr.com/ru/company/quadcode/blog/671254/</a> <br></div>

<script>
var article='/ru/company/quadcode/blog/671254-3/';
var langglobal='es';
function ajax_sbros_na_server(){// Сбрасываем переведённую статью на сервер
  //title = document.getElementsByClassName('title1')[0].innerHTML;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      if(this.responseText!='')alert( this.responseText );
    }
  };
  xhttp.open("POST", "ajax_sohr_perevod.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("text=" + encodeURIComponent(document.getElementById("bodyofthedocument").innerHTML.substring(0, 8000000)) + "&article=" + encodeURIComponent(article) + "&lang=" + encodeURIComponent(langglobal));
}
</script>


<a href="" onclick="alert(document.getElementById('bodyofthedocument').innerHTML);ajax_sbros_na_server();">...</a>
</body>
</html>
