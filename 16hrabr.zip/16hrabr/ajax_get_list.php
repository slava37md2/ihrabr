<?php
$page = $_POST[page];
if( $page == 1 )
  $homepage = file_get_contents('https://habr.com/ru/top/daily/');// 'Лучшие публикации за сутки _ Хабр.html'
else
  $homepage = file_get_contents('https://habr.com/ru/top/daily/page'.$page);// 'Лучшие публикации за сутки _ Хабр3.html'


$pos = strpos($homepage, '<body>') + 6;
$pos2 = strpos($homepage, '</body>');
$body = substr($homepage, $pos, $pos2 - $pos);


echo $body;
?>
