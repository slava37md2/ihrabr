<?php

$text = ' <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Вася</font> <font style="vertical-align: inherit;">Петя</font></font>     <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Вася2</font> <font style="vertical-align: inherit;">Петя2</font></font>';
    replace_font_to_span();
echo $text;

function replace_font_to_span(){
  global $text;
  $text = str_replace('</font></font>', '</span>', $text ); $text = str_replace('</font>', '</span>', $text );
  $pos_pred = 1; $id = 0;
  while( $pos_pred ){//echo $pos_pred;
    $pos = strpos( $text, '<font style="vertical-align: inherit;">', $pos_pred );
    if( $pos ){
      $pos2 = strpos( $text, '<font style="vertical-align: inherit;">', $pos + 1 );
      $text_with_spans = $text_with_spans.substr( $text, $pos_pred, $pos - $pos_pred ).'<span id="s'.$id.'" onclick="f('.$id.')">';
      $id++;
      if( $pos2 == $pos + 39 ){ $pos_pred = $pos + 78;       } // если двойной font
      else{ $pos_pred = $pos + 39;         } // если одинарный font
    }
    else{ $text_with_spans = $text_with_spans.substr( $text, $pos_pred, strlen( $text ) ); $pos_pred = false; }
  }
  $text = $text_with_spans;
}
?>
<script>
function f(id){
  //alert(document.getElementById('s'+id).innerHTML);
  document.getElementById('sp').innerHTML = document.getElementById('s'+id).innerHTML;
  openForm();
}
</script>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Кнопка, используемая для открытия контактной формы-фиксируется в нижней части страницы */
.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* Всплывающая форма-скрыта по умолчанию */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;height:80%;overflow-y:auto;
}

/* Добавление стилей в контейнер форм */
.form-container {
  max-width: 1080px;
  padding: 10px;
  background-color: white;
}

/* Поля ввода полной ширины */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* Когда входы получают фокус, сделайте что-нибудь */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Установите стиль для кнопки отправить/кнопка */
.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Добавьте красный цвет фона к кнопке отмена */
.form-container .cancel {
  background-color: red;
}

/* Добавьте некоторые эффекты наведения на кнопки */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>







<!--button class="open-button" onclick="openForm()">Открыть форму</button-->

<div class="form-popup" id="myForm">
  <form action="../action_page.php" class="form-container">
<b>Выберите предложенный другими посетителями перевод или введите свой вариант перевода для:<br>
    <span id="sp"></span></b>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<input type="radio" id="html" name="fav_language" value="HTML">
<label for="html">Volvo Введите свой вариант перевода или выберите предложенный другими посетителями перевод для: Добавить некоторые эффекты наведения на кнопки. Volvo Введите свой вариант переводаVolvo Введите свой вариант перевода или выберите предложенный другими посетителями перевод для: Добавить некоторые эффекты наведения на кнопки. Volvo Введите свой вариант переводаVolvo Введите свой вариант перевода или выберите предложенный другими посетителями перевод для: Добавить некоторые эффекты наведения на кнопки. Volvo Введите свой вариант перевода</label><hr>
<input type="radio" id="css" name="fav_language" value="CSS">
<label for="css">Volvo Введите свой вариант перевода или выберите предложенный другими посетителями перевод для: Добавить некоторые эффекты наведения на кнопки. </label><hr>
<input type="radio" id="javascript" name="fav_language" value="JavaScript">
<label for="javascript">Volvo Введите свой вариант перевода или выберите предложенный другими посетителями перевод для:</label><br><br>
    <label for="svoi_variant"><b>Введите свой вариант:</b></label>
    <input type="text" placeholder="Введите свой вариант" name="svoi_variant">


    <button type="submit" class="btn">Отправить</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Закрыть</button>
  </form>
</div>

