<?php
switch ($lang) {
    case 'es':
$title = 'habr en español';
$avtor = 'autor';
$prosmotrov = 'puntos de vista';
        break;
    case 'ch':
$lang = '';
$title = 'Habr 中文';
$avtor = '作者';
$prosmotrov = '意见';
        break;
    case 'fr':
$title = 'habr en français';
$avtor = 'auteur';
$prosmotrov = 'vues';
        break;
    case 'hi':
$title = 'सूचना प्रौद्योगिकी हिंदी में';
$avtor = 'लेखक';
$prosmotrov = 'विचारों की संख्या';
        break;
}

?>
