<?php
  $date_Y_m = date("Y-m"); $date_day = date("d");
		if(!is_dir ( 'articles/'.$date_Y_m ) )// Check if folder exists
			if(!mkdir( 'articles/'.$date_Y_m)) exit( 'The folder '.$date_Y_m.' was not created.' );
		if(!is_dir ( 'articles/'.$date_Y_m.'/'.$date_day ) )// Check if folder exists
			if(!mkdir( 'articles/'.$date_Y_m.'/'.$date_day)) exit( 'The folder '.$date_Y_m.'/'.$date_day.' was not created.' );

$article = str_replace("/", "-", $_POST[article]);
if( file_exists( 'articles/'.$date_Y_m.'/'.$date_day.'/'.$article.'.html' ) ){
  $body = file_get_contents('articles/'.$date_Y_m.'/'.$date_day.'/'.$article.'.html');//В файле только статья на русском
}
else{ // берём статью с хабра
  $homepage = file_get_contents('https://habr.com'.$_POST[article] );//'Что происходит с зеленой энергетикой _ Хабр.html'
  $pos = strpos($homepage, '<body>') + 6;
  $pos2 = strpos($homepage, '</body>');
  $body = substr($homepage, $pos, $pos2 - $pos);
}
echo $body;
?>
